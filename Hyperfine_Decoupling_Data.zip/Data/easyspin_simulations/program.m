clc;
clear all;
close all;

[FileName,PathName,FilterIndex] = uigetfile('*.txt; *.dat; *.mat');
simulation_data = importdata(strcat(PathName,FileName));

N = floor(log2(length(simulation_data(:,2))));
wname = 'db6';

% UDWT
% [swa, swd] = swt(simulation_data(:,2),N,wname);

% save(strcat('Approximation_',wname,'_',FileName),'swa','-ascii');
% save(strcat('Detail_',wname,'_',FileName),'swd','-ascii');

%DWT
[c, l] = wavedec(simulation_data(:,2),N,wname);

for i = 1:N
    
    swd = detcoef(c,l,i);
    swa = appcoef(c,l,wname,i);
    
    save(strcat('Detail_Level_',num2str(i),'_',wname,'_',FileName),'swd','-ascii');
    save(strcat('Approximation_Level_',num2str(i),'_',wname,'_',FileName),'swa','-ascii');
    
end

