file name convention:

.txt files are '\t' delimited, contains two columns, magnetic_field and signal_intensity  