file name convention:

1. denoised signal = molecule_ESRFreq_wavelet_denoised.dat

2. denoised super-hyperfine signal = molecule_ESRFreq_hf_wavelet_denoised.dat